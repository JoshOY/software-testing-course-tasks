package main.java.feeCounter.exceptions;

/**
 * Created by joshoy on 16/4/28.
 */
public class CrossYearDebtInvalidException extends Exception {
}
